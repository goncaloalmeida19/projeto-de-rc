#ifndef STOCK_SERVER_H
#define STOCK_SERVER_H

int stock_server();

int PORTO_BOLSA;
pid_t admin_console_pid;

#endif
