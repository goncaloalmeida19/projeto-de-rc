#ifndef ADMIN_CONSOLE_H
#define ADMIN_CONSOLE_H

int admin_console(char* admin_username, char* admin_password, const int PORTO_CONFIG);

#endif
